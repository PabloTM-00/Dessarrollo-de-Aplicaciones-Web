package es.uma.daw.libros.excepciones;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class LibroNoEncontrado extends RuntimeException {
    public LibroNoEncontrado(String mensaje) {
        super(mensaje);
    }
}
